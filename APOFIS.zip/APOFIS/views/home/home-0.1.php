<div id="cont_cube">
    <div id="vertical_block">
        <div id="position_logo">
            <div id="contaner_logo">
                <img id="logo" src="" alt="">
            </div>
        </div>
        <div id="position_text1">
            <div id="contaner_text1">
                <h1 id="text1">
                    Buscamos tu lugar en la informatica
                </h1>
            </div>
        </div>
        <div id="position_text2">
            <div id="contaner_text2">
                <h1 id="text2">
                    Porque creemos que la informatica puede cuidar y contribuir con la naturaleza
                </h1>
            </div>
        </div>
        <div id="position_text3">
            <div id="contaner_text3">
                <h1 id="text3">
                    El 5% general de las ganancias de la empresa estan destinadas a el cultivo de arboles nativos de la zona
                </h1>
            </div>
        </div>
    </div>
</div>