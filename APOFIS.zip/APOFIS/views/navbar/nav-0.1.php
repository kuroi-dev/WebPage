<div id="nav">
    <div id="block_nav">
        <div id="btn_home" class="btn-nav">
            <h1>HOME</h1>
        </div>
        <div id="btn_services" class="btn-nav">
            <h1>SERVICIOS</h1>
        </div>
        <div id="btn_we" class="btn-nav">
            <h1>NOSOTROS</h1>
        </div>
        <div id="btn_contact" class="btn-nav">
            <h1>CONTACTO</h1>
        </div>
    </div>
    <div id="block_nav1">
        <div id="btn_contact" class="btn-especial">
            <h1>English</h1>
        </div>
    </div>
</div>